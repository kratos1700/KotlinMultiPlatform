package org.example.dragonball

import kotlin.test.Test
import kotlin.test.assertEquals

class ComposeAppAndroidUnitTest {

    @Test
    fun example() {
        assertEquals(3, 1 + 2)
    }
}